https://superb-biscochitos-a2890f.netlify.app/
 LeadEI Harta Unităților de Învățământ din România
Vizualizare interactivă a școlilor, liceelor și grădinițelor
